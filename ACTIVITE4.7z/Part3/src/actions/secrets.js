const username = "xxxxxxxxx";
const password = "xxxxxxxxx";
export { username, password };
